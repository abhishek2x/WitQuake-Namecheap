
window.onload = function () {
    var typed = new Typed('#typed', {
        strings: ["Welcome to Witquake forum", "Explore Aricles", "Access Tutorials", "Develop Connections", "Discuss Problems", "Involve Learn Grow"],
        backSpeed: 15,
        smartBackspace: true,
        backDelay: 1200,
        startDelay: 1000,
        typeSpeed: 40,
        loop: true,
    });
};
